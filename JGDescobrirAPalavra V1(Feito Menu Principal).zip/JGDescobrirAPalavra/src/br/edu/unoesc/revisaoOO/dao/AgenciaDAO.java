package br.edu.unoesc.revisaoOO.dao;

import br.edu.unoesc.revisaoOO.modelo.Agencia;

public interface AgenciaDAO extends CrudDao<Agencia>{

}
