package br.edu.unoesc.revisaoOO.dao;

import br.edu.unoesc.revisaoOO.modelo.Cliente;

public interface ClienteDAO extends CrudDao<Cliente>{

}
