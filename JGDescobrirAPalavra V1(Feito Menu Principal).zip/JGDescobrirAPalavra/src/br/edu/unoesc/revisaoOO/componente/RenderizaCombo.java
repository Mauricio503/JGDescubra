package br.edu.unoesc.revisaoOO.componente;

public interface RenderizaCombo {
	String getText();
}
