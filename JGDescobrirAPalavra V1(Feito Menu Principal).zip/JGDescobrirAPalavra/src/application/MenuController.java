package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Menu;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class MenuController {

    @FXML
    private BorderPane bpPrincipal;

    @FXML
    private Menu mnCadastrar;

    @FXML
    private Menu mnLogin;
    
    @FXML
    void onCadastro(ActionEvent event) {
    	FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("clienteForm.fxml"));
		try {
			AnchorPane agenciaView = (AnchorPane) loader.load();
			bpPrincipal.setCenter(agenciaView);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
    }
    
    @FXML
    void onLogin(ActionEvent event) {

    }
	
}
