create table agencia(
		codigo int auto_increment not null,
        nome varchar(100) not null,
        numero int not null,
        primary key(codigo)
);